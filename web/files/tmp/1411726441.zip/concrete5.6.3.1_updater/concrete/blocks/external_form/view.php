<?php
	defined('C5_EXECUTE') or die("Access Denied.");
	include($controller->getExternalFormFilenamePath());
?>